# -*- coding: utf-8 -*-
#############################################################################

#############################################################################
{
    'name': 'Odoo 17 School Base',
    'version': '17.0.1.0.0',
    'depends': ['hr_contract', 'hr_holidays'],
    'data': [

    ],
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
