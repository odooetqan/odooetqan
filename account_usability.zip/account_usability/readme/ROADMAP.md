- Add a form view for the model `account.bank.statement` as Odoo SA
  privatized in EE the form view in V16.0.
