Example:

If you want to have an analytic account on all your *expenses*, set the
policy to *always* for the account of type *expense*. If you try to save
a journal items with an account of type *expense* without analytic
account, you will get an error message.
