## Module <ent_ohrms_loan>

#### 19.03.2025
#### Version 18.0.1.0.0
##### ADD

- Initial commit for Enterprise OpenHRMS Loan Management 
